document.getElementById("send-btn").addEventListener("click", sendMessage);
document.getElementById("user-input").addEventListener("keypress", function (event) {
    if (event.key === "Enter") {
        sendMessage();
    }
});

document.getElementById("theme-toggle").addEventListener("click", toggleTheme);

const chatBox = document.getElementById("chat-box");
const scrollTopBtn = document.getElementById("scroll-top-btn");
const scrollBottomBtn = document.getElementById("scroll-bottom-btn");

// Event listeners for scroll buttons
scrollTopBtn.addEventListener("click", () => {
    chatBox.scrollTo({ top: 0, behavior: "smooth" });
});

scrollBottomBtn.addEventListener("click", () => {
    chatBox.scrollTo({ top: chatBox.scrollHeight, behavior: "smooth" });
});

// Show/hide scroll buttons based on scroll position
chatBox.addEventListener("scroll", () => {
    const scrollPosition = chatBox.scrollTop;
    const maxScroll = chatBox.scrollHeight - chatBox.offsetHeight;

    scrollTopBtn.style.display = scrollPosition > 100 ? "block" : "none";
    scrollBottomBtn.style.display = scrollPosition < maxScroll - 100 ? "block" : "none";
});

// Function to send a user message
async function sendMessage() {
    const userInput = document.getElementById("user-input").value.trim();
    if (userInput === "") return;

    appendMessage(userInput, "user");
    document.getElementById("user-input").value = "";

    try {
        const botResponse = await fetchBotResponse(userInput);
        appendMessage(botResponse, "bot");
    } catch (error) {
        appendMessage("Oops! Something went wrong. Please try again later.", "bot");
    }
}

// Function to append a message to the chat box
function appendMessage(message, sender) {
    const messageDiv = document.createElement("div");
    messageDiv.classList.add("chat-message", sender);
    messageDiv.innerHTML = `<p>${message}</p>`;
    chatBox.appendChild(messageDiv);

    // Auto-scroll to the latest message
    chatBox.scrollTo({ top: chatBox.scrollHeight, behavior: "smooth" });
}

// Function to fetch bot response from the server
async function fetchBotResponse(userInput) {
    const API_URL = "http://127.0.0.1:5000/symptoms";

    try {
        const response = await fetch(API_URL, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ symptoms: [userInput] }),
        });

        if (!response.ok) {
            throw new Error(`Server Error: ${response.status} - ${response.statusText}`);
        }

        const data = await response.json();
        if (data.matched_diseases && data.matched_diseases.length > 0) {
            return `Possible diseases: ${data.matched_diseases.join(", ")}.`;
        } else {
            return "Sorry, I couldn't match any diseases. Please provide more details.";
        }
    } catch (error) {
        console.error("Error fetching bot response:", error);
        throw error;
    }
}

// Function to toggle between light and dark themes
function toggleTheme() {
    const body = document.body;
    const themeToggle = document.getElementById("theme-toggle");

    body.classList.toggle("dark-mode");
    themeToggle.textContent = body.classList.contains("dark-mode") ? "☀️" : "🌙";
}
